---
name: "pdf-engine"
description: "PDF Engine project (Gravity Forms to PDF AcroForm filler, React+Express, pdf-lib); signature image rendering fix on signature-fix branch"
---

- owns a website app/project called PDF Engine (PDF Generator & Field Mapper): Gravity Forms submissions to filled PDF templates, React 19 + Vite frontend, Express 5 backend, pdf-lib
- current issue: in the PDF generation step, the Gravity Forms signature field is mapped correctly but the PDF field gets filled with the signature image's filename instead of the actual image being fetched and rendered
- tried the patched pdfGenerator.js (signature fetched and drawn as image via pdf-lib); signature still did not render; uses a coding agent to make changes and wants a targeted prompt for it
- PDF Engine must work with multiple source WordPress sites (formsUrl and apiKey must come from each request's own source connection, never hardcoded)
- signature rendering now works on the signature-fix branch via the Automation Dispatch page
- next feature: replace the Push PDF to WP feature with "Store in Cloud" (send the generated PDF to a folder in a GCP bucket) in the Test Generation popup and the third page (Automation Dispatch)
- Store in Cloud should also create a record in the already-connected DB for each generated PDF
- wants gravity-forms-reader.php to add a custom Gravity Forms notification event "PDF Generated" that attaches the PDF, and wants PDF generation both automatically on entry submission and from the React app via the endpoint (plugin file changes only if possible)
- regression at a major checkpoint: PDF template records no longer persist to the connected DB (other DB persistence may also be broken), so new templates are not available to the renderer (it fetches from DB); can't roll back, must fix forward without losing progress
- template DB save regression fixed (missing upsertPdfTemplateRecord import in server.js); next wants edit and delete operations for templates (previously built in an AI Studio version), using Kilo Code in VS Code with incremental prompts, same architecture and flow
- decided to skip the form_mappings ON DELETE RESTRICT migration (only a few people use the app); keeping the app-level in-use check for template delete
