---
name: "gravity-form-page-codes"
description: "Gravity Form 20 reused on payment pages with internal codes (BNM, BKJ...); Elementor payment dashboard snippet, names-to-codes mapping, theme styling."
---

- wants to use one Gravity Form on 5 different pages, each page assigned an internal code so payments can be tracked internally; wants the quickest implementation
- now has 9 page codes (BNM, BKJ, BJL, BRA, BBY, BX, AF, BRR, BHK) on Gravity Form ID 20; payment dashboard runs as one Code Snippets PHP snippet with shortcodes in Elementor (stats, transaction summary, full view in an Elementor popup)
- will map people names to the internal codes himself in the snippet config, to show automatically in the Elementor views
- dashboard styling: dark theme, cyan #5BCEFF, Sora font, square corners; amounts in AUD; plans to password-protect the dashboard page later
- names are now filled in the snippet's names map; chose to let logged-in subscribers (capability 'read') see the transaction views, not only admins
- added a new dropdown field (ID 6) to Form 20 and wants it shown in the transaction views and CSV export
