---
name: "payment-confirmation-message"
description: "Gravity Forms + Stripe payment confirmation message (custom HTML) branded HomeworkFixer, support email support@homeworkfixer.com; replaced old Chelson Gordon branding."
---

- building a custom HTML confirmation message for a Gravity Forms form with the Stripe add-on, showing amount paid and payment status
- branding is HomeworkFixer (replacing earlier "Chelson Gordon Consultancy" text); support email is support@homeworkfixer.com
- wants a clean, modern look with good spacing and padding
- wants the contact row to show the customer's email using merge tag {Email:2}
