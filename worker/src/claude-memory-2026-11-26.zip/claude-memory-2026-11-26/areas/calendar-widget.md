---
name: "calendar-widget"
description: "Google Calendar widget (multi-country calendars, admin add/delete) pasted into an Elementor HTML block on a WordPress site; access-control review."
---

- code lives in an Elementor HTML block (WordPress site)
- asked for an analysis of how access control on the calendar widget is set up
