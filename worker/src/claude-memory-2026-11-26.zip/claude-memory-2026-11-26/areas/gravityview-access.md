---
name: "gravityview-access"
description: "Restricting a GravityView on a WordPress page to selected users (aibtglobal.edu.au staff incl. Yi Jing); view-access whitelist by email."
---

- needs a GravityView on a WP page viewable only by selected email users: y.panjanani@aibtglobal.edu.au, c.dejsakultorn@aibtglobal.edu.au, and Yi Jing (y.ong@aibtglobal.edu.au, y.ong@chelsongordon.com); also c.dejsakultorn@chelsongordon.com and c.dejsakultorn@vconsultancy.com.au
- GravityView View ID is 41293; using an email-whitelist PHP snippet (can_render filter plus template_redirect on the page); page ID still to be filled in
- task: new GravityView on myVC intranet for the Certificate Request form (Gravity Form ID 1), staff view-only, no approval; shortcode goes on https://myvc.com.au/qa/certificate-request/certificate-request-admin-view/ (Elementor, small title plus shortcode, page 100% width); link then goes to Yi Jing, viewer is Yi Jing's CG email
- said the certificate request view and page setup is done
