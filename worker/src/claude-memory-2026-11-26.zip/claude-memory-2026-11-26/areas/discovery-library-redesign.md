---
name: "discovery-library-redesign"
description: "Discovery Library React (Vite) redesign deployed to WordPress page /redesign via PHP snippet loader (DL_Loader), bare-page mode; working."
---

- React/Vite build of "Discovery Library Redesign" (dist/assets, files renamed to homepage.js and homepage.css) deployed on a WordPress site, on the page with slug `redesign`; files live in wp-content/uploads/redesign/
- loads via a PHP snippet class `DL_Loader` (frontend only) with BARE = true, serving the app as a standalone HTML page with just `<div id="root">`; confirmed working live
- Google Fonts loaded through an `@import` as the first line of homepage.css
- develops on Windows (PowerShell)
- maintains a "Discovery Library Content CPTs" WordPress plugin (training_video, upcoming_session, useful_link_video) feeding the React frontend via REST; adding a 4th CPT `newsletter` (date field with calendar UI, file URL), with per-post and per-field REST visibility toggles
- new SPA build of discovery-library prototyped in Google AI Studio (React 19, Vite 6, three, motion, hash-routed /#/); vite.config sets base './', cssCodeSplit false, fixed outputs homepage.js and homepage.css; considering moving the WP loader from a snippet to a plugin
- React app has two Gravity Forms mount points already styled as cards: `#gravity-form-mount` (Book a Consultation / enquiry card) and `#gravity-form-session-mount` (inside the session "Reserve Spot" modal); wants two real Gravity Forms mounted there; app is served by the WP plugin loader (folder discovery-library-app, bare page on /redesign)
- Gravity Forms in use on the app: contact form ID 2 (mounted at #gravity-form-mount on the /contact page) and reservation form ID 5 (#gravity-form-session-mount, "Reserve Spot" modal on /sessions, which passes data-session-id/title/date); the app already has the dark-glass GF styling (src/styles/gravity-forms.css) and confirmation handlers (useGravityFormMount, src/services/gravityFormHandler.js); forms are being rendered via a WP snippet class `DL_GF_Inject` (holders dl-src-enquiry and dl-src-session) rather than editing the loader plugin
